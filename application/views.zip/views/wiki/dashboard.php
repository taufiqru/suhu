<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      Dashboard
      <small>Potensi Ancaman Siber</small>
    </h1>
  </section>

  <section class="content" >
    <div class="callout callout-danger">
      <h4>Perhatian!</h4>
      <p>Wiki Malware Sedang dalam tahap pengembangan. Semua data signature di ekstrak langsung dari file laporan harian (.docx), sehingga masih terdapat beberapa kesalahan (e.g typo, format salah). Jika menemukan error, bug ataupun penyajian data yang salah, mohon hubungi admin. Terima Kasih</p>
      <a href="<?=base_url()?>view" class="btn btn-block btn-primary" style="width:200px;text-decoration:none"> Cari Signature</a>
    </div>
    <!--
    
      <div class="col-md-12">
        <div class="box box-primary">
          <div class="box-header with-border">
          </div>
          <div class="box-body">
          </div>
        </div>
      </div>    
    
    -->
    <div class="row">
      <div class="col-lg-3 col-xs-6">
        <!-- small box -->
        <div class="small-box bg-teal">
          <div class="inner">
            <h3><?=$jumlah_data?></h3>

            <p>Baris Data</p>
          </div>
          <div class="icon">
            <i class="ion ion-stats-bars"></i>
          </div>
          <a href="#" class="small-box-footer"></a>
        </div>
      </div>
      <div class="col-lg-3 col-xs-6">
        <!-- small box -->
        <div class="small-box bg-purple">
          <div class="inner">
            <h3><?=$jumlah_signature?></h3>

            <p>Signature Unik</p>
          </div>
          <div class="icon">
            <i class="fa fa-bug"></i>
          </div>
          <a href="#" class="small-box-footer"></a>
        </div>
      </div>
      <div class="col-lg-3 col-xs-6">
        <!-- small box -->
        <div class="small-box bg-orange">
          <div class="inner">
            <h3><?=$jumlah_dokumen?></h3>

            <p>Laporan Harian</p>
          </div>
          <div class="icon">
            <i class="fa fa-file-text"></i>
          </div>
          <a href="#" class="small-box-footer"></a>
        </div>
      </div>
      <div class="col-lg-3 col-xs-6">
        <!-- small box -->
        <div class="small-box bg-maroon">
          <div class="inner">
            <h3><?=$jumlah_lokasi?></h3>

            <p>Lokasi</p>
          </div>
          <div class="icon">
            <i class="fa fa-globe"></i>
          </div>
          <a href="#" class="small-box-footer"></a>
        </div>
      </div>
    </div> 
    <div class="row">
      <div class="col-lg-12">
        <div class="box box-info">
          <div class="box-header with-border">
            <h3 class="box-title">Top Signature</h3>

            <div class="box-tools pull-right">
              <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
              </button>
              <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
            </div>
          </div>
          <!-- /.box-header -->
          <div class="box-body">
            <div class="table-responsive">
              <table class="table no-margin">
                <thead>
                  <tr>
                    <th>Signature</th>
                    <th>Jumlah Analisis</th>
                  </tr>
                </thead>
                <tbody>
                  <?php foreach($top_signature as $row):?>
                    <tr>
                      <td><?=$row['signature_name']?></td>
                      <td><?=$row['jumlah']?></td>
                    </tr>
                  <?php endforeach;?>
                </tbody>
              </table>
            </div>
            <!-- /.table-responsive -->
          </div>
        </div>
      </div>
    </div>     
  </section>
  
</div>
<!-- /.content-wrapper -->