<script type="text/javascript">
  $(document).ready(function(e){
      e.preventDefault();
      alert("Hello world");
    });
</script>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	Hello
</body>
</html>