<!-- Main Footer -->
  <footer class="main-footer">
    <!-- To the right -->
    <div class="pull-right hidden-xs">
      Pushansiber
    </div>
    <!-- Default to the left -->
    <strong>Lab Malware Pushansiber &copy; 2018</strong>
  </footer>