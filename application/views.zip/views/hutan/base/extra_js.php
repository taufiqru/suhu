<link rel="stylesheet" href="<?=base_url();?>theme/plugins/datatables/dataTables.bootstrap.css">
<script src="<?=base_url();?>theme/plugins/datatables/jquery.dataTables.min.js"></script>
<script src="<?=base_url();?>theme/plugins/datatables/dataTables.bootstrap.min.js"></script>
<!-- SlimScroll -->
<script src="<?=base_url();?>theme/plugins/slimScroll/jquery.slimscroll.min.js"></script>
<script>
  $(function () {   
    $("#example2").DataTable();
  });
</script>