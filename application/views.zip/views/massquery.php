<!DOCTYPE html>
<html>
<head>
	<title>Mass Query</title>
</head>
<body>
	<?php 
		$hitung_tipedata=0;
		$hitung_truncate=0;
		$val1=0;
		$val2=0;
		$val3=0;
		foreach($tables as $row){
			if($row!='xyz_provinsi' && $row!='xyz_kabupaten' && $row!='xyz_kph' && $row!='xyz_unit_kph' && $row!='folder' && $row!='subfolder' && $row!='xyz_general_settings' && $row!='xyz_user'){
				
// 				$sql1="ALTER TABLE `".$row."` CHANGE `provinsi` `provinsi` INT NOT NULL, CHANGE `kabupaten` `kabupaten` INT NOT NULL, CHANGE `kph` `kph` INT NOT NULL, CHANGE `kph_unit` `kph_unit` INT NOT NULL;
// ";
// 				$tipedata=$this->db->query($sql1);
// 				if($tipedata){
// 					$hitung_tipedata++;
// 				}

// 				$sql2="TRUNCATE `".$row."`";
// 				$truncate=$this->db->query($sql2);
// 				if($truncate){
// 					$hitung_truncate++;
// 				}

				$field="kph_unit";
				$tabel="unit_kph";

				$sql="ALTER TABLE `".$row."` ADD FOREIGN KEY (`".$field."`) REFERENCES `xyz_".$tabel."`(`id_".$tabel."`) ON DELETE RESTRICT ON UPDATE RESTRICT;";
				//$exec=$this->db->query($sql);
				if($exec){
					$val1++;
				}

				$sql="ALTER TABLE `".$row."` ADD INDEX(`".$field."`);";
				//$exec=$this->db->query($sql);
				if($exec){
					$val2++;
				}

				$sql="ALTER TABLE `".$row."` ADD FOREIGN KEY (`".$field."`) REFERENCES `xyz_".$tabel."`(`id_".$tabel."`) ON DELETE RESTRICT ON UPDATE RESTRICT;";
				//$exec=$this->db->query($sql);
				if($exec){
					$val3++;
				}	
			}
			
		}
		//echo "Berhasil merubah ".$hitung_tipedata." tipe data tabel";
		//echo "Berhasil truncate ".$hitung_truncate." tabel";	
		echo "merubah".$val1." tabel ".$field."<br>";
		echo "merubah".$val2." tabel ".$field."<br>";
		echo "merubah".$val3." tabel ".$field."<br>";
	
		
	?>
	
	
	
</body>
</html>